# ML Workshop CNN

Workshop over Convolutional Neural Networks voor het Vak Machine-Learning van de opleiding Artificial Intelligence aan de Hogeschool Utrecht.


`pip install -r requirements.txt`

Maak vervolgens de opdrachten in deze volgorde:
1. `1-RegularNN.ipynb`
2. `2-CNN-layers_explained.ipynb`
3. `3-CNN_CIFAR_opdr.ipynb`


Stan Meyberg, Esmeralda de Wolf, Sinem Ertem, Casper Smet
